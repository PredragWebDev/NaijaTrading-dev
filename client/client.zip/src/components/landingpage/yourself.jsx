import "./yourself.css";

export const Yourself = (props) => {
  return (
    <div className='yourself'>
      <div className='mainboard'>
        
        <div className='txt'>
          <div className="text1">You have the option to trade independently or engage in competition with others.</div>
          <div className="text2">You can choose to hone your trading and investment skills individually, or you can participate in a game with numerous like-minded and knowledgeable investors to compete for the top position.
          </div>
        </div>
        <div className='img'>
          <img src="./img/yourself.svg" alt="" className="image"/>
        </div>
      </div>
      
    </div>
  )
}
