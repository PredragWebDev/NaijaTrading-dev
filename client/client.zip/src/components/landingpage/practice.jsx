import "./practice.css";

export const Practice = (props) => {
  return (
    <div className='practice'>
      <div className='mainboard'>
        
        <div className='txt'>
          <div className="text1">Crypto trading with virtual money to gain experience.</div>
          <div className="text2">You don't need to make any deposit to start practicing trading. Use virtual money to enhance your understanding of the crypto market and learn how to use an online brokerage by using the Trade-Ed Simulator. This tool will give you the opportunity to build your confidence before investing your real money.
          </div>
        </div>
        <div className='img'>
          <img src="./img/mobile.svg" alt="" className="image"/>
        </div>
      </div>
      
    </div>
  )
}
