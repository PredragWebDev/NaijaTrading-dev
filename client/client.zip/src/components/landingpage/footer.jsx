import "./footer.css";

export const Footer = () => {
    return (
        <div id='footer'>
            <div className='footer'>
                <p>
                    &copy; 2023, Trade-Ed
                </p>
            </div>
        </div>
    )
}